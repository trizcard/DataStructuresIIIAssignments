#ifndef __CHECAGEM_H__
#define __CHECAGEM_H__

#include "../headers/estrutura.h"

int checa_consistencia(reg_cabecalho*);

#endif