#ifndef __FORNECIDAS_H__
#define __FORNECIDAS_H__

#include "../headers/estrutura.h"

void binarioNaTela(char*);
void scan_quote_string(char*);

#endif