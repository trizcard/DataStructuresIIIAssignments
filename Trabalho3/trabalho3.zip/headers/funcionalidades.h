#ifndef __FUNCIONALIDADES_H__
#define __FUNCIONALIDADES_H__

#include "../headers/estrutura.h"

void comando11(char* );
void comando12(char* );
void comando13(char*,int);
void comando14(char*,int);

#endif