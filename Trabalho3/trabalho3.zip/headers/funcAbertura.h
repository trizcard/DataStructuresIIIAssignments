#ifndef __ABERTURA_H__
#define __ABERTURA_H__

#include "../headers/estrutura.h"

FILE* abrir_leitura_binario(char*);


#endif